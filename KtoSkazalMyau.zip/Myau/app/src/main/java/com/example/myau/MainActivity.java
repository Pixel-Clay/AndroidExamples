package com.example.myau;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class MainActivity extends AppCompatActivity {

    private ImageButton amogus, cat;
    private MediaPlayer amogusSound, catSound;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        amogus = findViewById(R.id.amogus);
        cat = findViewById(R.id.cat);

        amogusSound = MediaPlayer.create(this, R.raw.amogus);
        catSound = MediaPlayer.create(this, R.raw.cat);

        cat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                playSound(catSound);
            }
        });

        amogus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                playSound(amogusSound);
            }
        });
    }
    private void playSound(MediaPlayer sound){
        if (sound.isPlaying()){
            sound.pause();
            sound.seekTo(0);
        }
        sound.start();
    }
}