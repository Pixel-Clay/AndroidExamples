package com.example.theme132;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Point;
import android.os.Bundle;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    public void onClick(View v) {

     // Получить ширину и высоту

//        Display display = getWindowManager().getDefaultDisplay();
//        Point point = new Point();
//        display.getSize(point);
//        int screenWidth = point.x;
//        int screenHeight = point.y;
//
//        // Теперь получим необходимую информацию
////        String width = Integer.toString(screenWidth);
////        String height = Integer.toString(screenHeight);
//
//        String info = "Ширина: " + screenWidth + "; Высота: " + screenHeight;
//
//        TextView infoTextView = findViewById(R.id.text454);
//        infoTextView.setText(info);


        //Получить плотность пикселей
//
//        DisplayMetrics metrics = new DisplayMetrics();
//        getWindowManager().getDefaultDisplay().getMetrics(metrics);
//
//        String strScreen = "";
//        strScreen += "Width: " + String.valueOf(metrics.widthPixels) + " pixels"
//                + "\n";
//        strScreen += "Height: " + String.valueOf(metrics.heightPixels) + " pixels"
//                + "\n";
//        strScreen += "The Logical Density: " + String.valueOf(metrics.density)
//                + "\n";
//        strScreen += "X Dimension: " + String.valueOf(metrics.xdpi) + " dot/inch"
//                + "\n";
//        strScreen += "Y Dimension: " + String.valueOf(metrics.ydpi) + " dot/inch"
//                + "\n";
//        strScreen += "The screen density expressed as dots-per-inch: "
//                + metrics.densityDpi + "\n";
//        strScreen += "A scaling factor for fonts displayed on the display: "
//                + metrics.scaledDensity + "\n";
//
//        TextView infoTextView = findViewById(R.id.text454);
//        infoTextView.setText(strScreen);
//


        //Яркость

//        TextView infoTextView = findViewById(R.id.text454);
//
//        try {
//            int curBrightnessValue = android.provider.Settings.System.getInt(
//                    getContentResolver(),
//                    android.provider.Settings.System.SCREEN_BRIGHTNESS);
//            infoTextView.setText("Текущая яркость экрана: " + curBrightnessValue);
//        } catch (Settings.SettingNotFoundException e) {
//            e.printStackTrace();
//        }
    }
}
